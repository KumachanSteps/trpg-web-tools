window.ReportParser = window.ReportParser || {};
