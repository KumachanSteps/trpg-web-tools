window.OCCUPATIONS = [
  {
    id: "private_detective_6e",
    name: "私立探偵",
    ruleType: "6e",
    ruleLabels: ["6版"],
    source: "6版・基本ルールブック",
    sourceShort: "基本ルールブック",
    page: "p.x",
    description: "調査、尾行、聞き込みなどを行う職業サンプル。",
    skills: ["言いくるめ", "鍵開け", "写真術", "心理学", "図書館", "値切り", "法律", "目星"],
    skillOptions: [],
    pointFormula: "EDU × 20",
    credit: "",
    special: "",
    alliesExample: "",
    keywords: ["探偵", "調査", "尾行", "聞き込み"],
    note: "",
  },
  {
    id: "journalist_2015",
    name: "ジャーナリスト",
    ruleType: "6e",
    ruleLabels: ["6版", "2015"],
    source: "クトゥルフ2015",
    sourceShort: "クトゥルフ2015",
    page: "p.x",
    description: "事件や社会問題を追い、取材と文章で真相に迫る職業サンプル。",
    skills: ["言いくるめ", "写真術", "心理学", "説得", "図書館", "母国語", "歴史", "目星"],
    skillOptions: [],
    pointFormula: "EDU × 20",
    credit: "",
    special: "情報収集や取材に関する補足をここに記載。",
    alliesExample: "",
    keywords: ["記者", "取材", "報道", "記事"],
    note: "",
  },
  {
    id: "doctor_7e",
    name: "医師",
    ruleType: "7e",
    ruleLabels: ["7版"],
    source: "7版・基本ルールブック",
    sourceShort: "7版・基本ルールブック",
    page: "p.x",
    description: "医学的知識と治療技術を持つ専門職。",
    skills: ["医学", "応急手当", "科学（生物学）", "科学（薬学）", "心理学", "ほかの言語", "任意の専門技能2つ"],
    skillOptions: [],
    pointFormula: "EDU × 4",
    credit: "30～80%",
    special: "",
    alliesExample: "",
    keywords: ["医療", "病院", "治療", "医者"],
    note: "",
  },
  {
    id: "butler_pulp",
    name: "執事",
    ruleType: "pulp",
    ruleLabels: ["パルプ"],
    source: "パルプクトゥルフ",
    sourceShort: "パルプクトゥルフ",
    page: "p.x",
    description: "主人や家の管理を支える、知識と社交性を備えた職業サンプル。",
    skills: [
      "応急手当",
      "鑑定もしくは経理",
      "聞き耳",
      "芸術／製作（任意の分野、例：料理、裁縫、理髪）",
      "心理学",
      "目星",
      "ほかの言語",
      "個人的な専門または時代に関連する任意のほかの2つの技能",
    ],
    skillOptions: [],
    pointFormula: "EDU × 4",
    credit: "9～40%（雇い主の地位と＜信用＞で変化する）",
    special: "",
    alliesExample: "ほかの家庭の給仕係、地元のビジネスマン、店員。",
    keywords: ["執事", "使用人", "給仕", "家事"],
    note: "",
  },
];

window.OCCUPATIONS_7E_EXTRA = [
];


window.OCCUPATIONS_6E_COC2015 = [
];


window.OCCUPATIONS_7E_BASIC = [
];


window.OCCUPATIONS_7E_PULP = [
];


window.OCCUPATIONS_GASLIGHT = [
];


window.OCCUPATIONS_DREAMLAND = [
];


window.OCCUPATIONS_TEIKOKU = [
];


window.OCCUPATIONS_HIEIZAN = [
];
